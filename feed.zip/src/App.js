import React, {Component} from 'react';
import logo from './logo.svg';
import './App.css';
import ThirdParty from "./Components/fetchAPI";
import "bootstrap/dist/css/bootstrap.css";

class App extends React.Component {
  
  // state = {
  //   isLoading: true,
  //   posts: [],
  //   error: null
  // };
  
  // // Fetch API
  // fetchPosts() {
  //   fetch(`https://cryptic-brook-24225.herokuapp.com/posts`)
  //     .then(response => response.json())
  //     .then(data =>
  //       this.setState({
  //         posts: data,
  //         isLoading: false
  //       })
  //     )
  //     .catch(error => this.setState({ error, isLoading: false }));
  // }

  // componentDidMount() {
  //   this.fetchPosts();
  // }

  render() {
    // const { isLoading, posts, error } = this.state;
    return (
      <section className="container col-6">
        <h2>Facebook Post</h2>

        <div className="jumbotron">

          <ThirdParty />
          {/* {!isLoading ? (
            Object.keys(posts).map(key => (
              <Post key={key} body={posts[key]} />
            ))
          ) : (
            <span>Loading...</span>
          )} */}
        </div>
      </section>
    );
  }
}

export default App;
