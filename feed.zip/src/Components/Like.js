import React, { Component } from "react";
import { FacebookProvider, Page } from "react-facebook";

export default class Example extends Component {
  render() {
    return (
      <FacebookProvider appId="424183798311011">
        <Page href="https://www.facebook.com" tabs="timeline" />
      </FacebookProvider>
    );
  }
}
