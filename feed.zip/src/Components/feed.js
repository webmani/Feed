import React from "react";

const Post = ({ body }) => {
  return (
    <div>      
      {body.map(post => {
        const { id, name, first_name } = post;
        return (
          <div key={id}>
            <h2>{name}</h2>
            <p>{first_name}</p>
            <hr />
          </div>
        );
      })}
    </div>
  );
};

export default Post;
