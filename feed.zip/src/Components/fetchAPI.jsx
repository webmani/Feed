import React, { Component } from "react";

class ThirdParty extends Component {
  state = {
    isLoading: true,
    users: [],
    error: null
  };
  componentDidMount() {
    this.fetchUsers();
  }
  fetchUsers() {
    fetch(
      `https://graph.facebook.com/me?fields=name,feed{likes.limit(10){name,link,username,picture,pic},caption,full_picture,name,message,link,picture,shares,comments{likes,like_count}}&access_token=EAAGByvyeKGMBANLDTsP1uHsZCQJ8Pbl9edS6DMKc8KQSj8mOx3HckTa6s5ociBe7ulFHmnTd6oneAZC0r7Lj46ZAZAvwj3sVTJZBSHPLj4uedsnSUuZC3MRC7CxZCLqfy2xeby0qSkuJGTa9SxgVijaBZCOvB8ZBo8NyA8SIt3MYuBdeR2k0WJjq1ZBjAvZBxfazZAoZD`
    )
      .then(response => response.json())
      .then(data =>
        this.setState({
          users: data,
          isLoading: false
        })
      )
      .catch(error => this.setState({ error, isLoading: false }));
  }
  render() {
    const {  users } = this.state;
    console.log(users.feed);
    return (
      <React.Fragment>
        <h3>Random Users</h3>
        Name: {users.name}
{/*        
        {users.map( feeddetail => {
          
        })} */}
        {/* {error ? <p>{error.message}</p> : null}
        {!isLoading ? (
          users.map(user => {
            const { name } = user;
            return (
              <div key={name}>
                <p>Name: {name}</p>
              </div>
            );
          })
        ) : (
          <h3>Loading...</h3>
        )} */}
      </React.Fragment>
    );
  }
}

export default ThirdParty;
